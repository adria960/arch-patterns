package com.vinsguru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CqrsPatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
