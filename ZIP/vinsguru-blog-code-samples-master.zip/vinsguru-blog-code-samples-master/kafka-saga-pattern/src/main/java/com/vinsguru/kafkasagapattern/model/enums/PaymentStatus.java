package com.vinsguru.kafkasagapattern.model.enums;

public enum PaymentStatus {

    APPROVED,
    REJECTED;

}
