package com.vinsguru.kafkasagapattern.model.enums;

public enum OrderStatus {

    ORDER_CREATED,
    ORDER_CANCELLED,
    ORDER_COMPLETED

}
