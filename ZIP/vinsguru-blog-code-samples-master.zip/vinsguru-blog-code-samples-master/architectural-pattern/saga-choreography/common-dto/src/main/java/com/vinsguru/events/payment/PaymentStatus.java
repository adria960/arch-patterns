package com.vinsguru.events.payment;

public enum PaymentStatus {
    RESERVED,
    REJECTED;
}
