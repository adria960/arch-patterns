package com.vinsguru.materializedview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaterializedViewApplicationTests {

	@Test
	void contextLoads() {
	}

}
