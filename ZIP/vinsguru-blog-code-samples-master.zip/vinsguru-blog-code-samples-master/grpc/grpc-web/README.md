# gRPC Web Example

This project contains the sample code for developing a gRPC web application to make unary/server-streaming gRPC calls.

More info can be found [here](https://www.vinsguru.com/grpc-web-example/).