# gRPC Reactive Error Handling / Input Validation

This is a sample project which demonstrates gRPC input validation and emitting error event using reactor.

## How to run

- Clone the project
- Do `mvn clean compile`
- Run the **_ReactiveGrpcTest_** under `src/test/java`