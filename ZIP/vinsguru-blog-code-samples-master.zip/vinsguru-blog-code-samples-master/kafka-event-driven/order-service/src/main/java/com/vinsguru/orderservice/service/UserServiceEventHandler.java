package com.vinsguru.orderservice.service;

import com.vinsguru.orderservice.entity.User;

public interface UserServiceEventHandler {
    void updateUser(User user);
}
